<!-- Header Start -->
			<div class="header">
				<div class="container">
					<div class="logo">
						<a href="project.php"><img src="images/logo.png"></a>
					</div>
					<div class="searchbar">
						<form>
							<input type="search" class="searchField" placeholder="Search for products & brands">
						</form>
					</div>
					<div class="headerright">
						<ul>
							<li><a href="#"><i class="fas fa-heart"></i> Wishlist</a></li>
							<li><a href="#"><i class="fas fa-shopping-cart"></i> Cart</a></li>
							<li><a href="#" class="signBtn">Login & Register</a></li>
						</ul>
					</div>
				</div>
			</div>
			<!-- Header End -->

			