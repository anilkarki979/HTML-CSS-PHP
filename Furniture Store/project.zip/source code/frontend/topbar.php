<div class="topbar">
				<div class="container">
					<!-- Top Center -->
					<div class="topcenter">
						<ul>
							<li><a href="project.php">Home</a></li>
							<!-- <li><a href="#">Company Profile</a></li>
							<li><a href="#">Payment Accept</a></li>
							 --><li><a href="#">Delivery</a></li>
							<li><a href="contact.php">Contact Us</a></li>
						</ul>
					</div>

					<!-- Top Right -->
					<div class="topright">
						<ul>
							<li><a href="#"><i class="fas fa-phone"></i> +977-98**-******</a></li>
							<li><a href="#"><i class="fas fa-user"></i> My Profile <i class="fas fa-caret-down"></i></a>
								<ul class="myprofile-dropdown">
									<li><a href="#">My Order</a></li>
									<li><a href="#">My Wishlist</a></li>
									<li><a href="#">Pending Request</a></li>
									<li><a href="#">Delivered Order</a></li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<!-- Topbar End -->
