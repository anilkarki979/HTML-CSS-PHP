	<!-- Footer Start -->
				<div class="footer">
				

				
				<div class="copyright">
					<div class="container">
						<h5>&copy; 2019  Khwopa| Created by SrijanDangol </h5>
					</div>
				</div>

			