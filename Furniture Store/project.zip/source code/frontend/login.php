		<!-- Login Signup Form Start -->
				<div class="loginBox">
					<div class="closeBtn"><i class="fas fa-times"></i></div>
					<div class="loginForm">
						<h3>Login Form</h3>
						<form>
							<input class="textField" type="text" placeholder="Username or Email">
							<input class="textField" type="password" placeholder="Password">
							<input class="submitBtn" type="submit" value="Login">
						</form>
					</div>
					<div class="registerForm">
						<h3>Register Form</h3>
						<form action="" method="POST" name="register">
							<input class="textField" type="text" placeholder="First Name" name="firstname">
							<input class="textField" type="text" placeholder="Last Name" name="lastname">
							<input class="textField" type="text" placeholder="Username" name="username">
							<input class="textField" type="email" placeholder="Your Email" name="email">
							<input class="textField" type="password" placeholder="New Password" name="password">
							<input class="textField" type="password" placeholder="Confirm Password" name="re_password">
							<input class="submitBtn" type="submit" value="Register">
						</form>
					</div>
				</div>
				<!-- Login Signup Form End -->
