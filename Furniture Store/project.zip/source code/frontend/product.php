<!-- Product Area Start -->
				<div class="product-area">
					<div class="container">
						<h3>Top Selling Products</h3>

						<div class="col-3">
							<a href="#">
								<img src="images/cabinate.jpeg" alt="">
								<div class="caption">
									<h4>Liquor Cabinet</h4>
									
									<button class="price"><i class="fas fa-dollar-sign"></i>59 </button>
								</div>
								<button class="productViewBtn">View Product</button>
							</a>
						</div>

						<div class="col-3">
							<a href="#">
								<img src="images/cup2.jpeg" alt="">
								<div class="caption">
									<h4>Cupboard</h4>
									<button class="price"><i class="fas fa-dollar-sign"></i>99 </button>
								</div>
								<button class="productViewBtn">View Product</button>
							</a>
						</div>

						<div class="col-3">
							<a href="#">
								<img src="images/self.jpeg" alt="">
								<div class="caption">
									<h4>shelf</h4>
									<button class="price"><i class="fas fa-dollar-sign"></i>150 </button>
								</div>
								<button class="productViewBtn">View Product</button>
							</a>
						</div>

						<div class="col-3">
							<a href="#">
								<img src="images/imagescase1.jpeg" alt="">
								<div class="caption">
									<h4>bookcase</h4>
									<button class="price"><i class="fas fa-dollar-sign"></i>80 </button>
								</div>
								<button class="productViewBtn">View Product</button>
							</a>
						</div>

						
						<div class="col-3">
							<a href="#">
								<img src="images/couch.jpeg" alt="">
								<div class="caption">
									<h4>couch</h4>
									<button class="price"><i class="fas fa-dollar-sign"></i>200 </button>
								</div>
								<button class="productViewBtn">View Product</button>
							</a>
						</div>

						<div class="col-3">
							<a href="#">
								<img src="images/coffeee.jpeg" alt="">
								<div class="caption">
									<h4>coffee table</h4>
									<button class="price"><i class="fas fa-dollar-sign"></i>55</button>
								</div>
								<button class="productViewBtn">View Product</button>
							</a>
						</div>

						<div class="col-3">
							<a href="#">
								<img src="images/coffee1.jpeg" alt="">
								<div class="caption">
									<h4>coffee table</h4>
									<button class="price"><i class="fas fa-dollar-sign"></i> </button>
								</div>
								<button class="productViewBtn">View Product</button>
							</a>
						</div>

						<div class="col-3">
							<a href="#">
								<img src="images/bookcase.jpeg" alt="">
								<div class="caption">
									<h4>Bookcase</h4>
									<button class="price"><i class="fas fa-dollar-sign"></i>999 </button>
								</div>
								<button class="productViewBtn">View Product</button>
							</a>
						</div>

						<h3>Fresh Stock</h3>
						<div class="col-3">
							<a href="#">
								<img src="">
								<div class="caption">
									
									<button class="price"><i class="fas fa-dollar-sign"></i> </button>
								</div>	
								<button class="productViewBtn">View Product</button>
							</a>
						</div>
						<div class="col-3">
							<a href="#">
								<img src="#">
								<div class="caption">
									
									<button class="price"><i class="fas fa-dollar-sign"></i> </button>
								</div>	
								<button class="productViewBtn">View Product</button>
							</a>
						</div>
						<div class="col-3">
							<a href="#">
								<img src="#">
								<div class="caption">
									
									<button class="price"><i class="fas fa-dollar-sign"></i></button>
								</div>	
								<button class="productViewBtn">View Product</button>
							</a>
						</div>
						<div class="col-3">
							<a href="#">
								<img src="#">
								<div class="caption">
									
									<button class="price"><i class="fas fa-dollar-sign"></i></button>
								</div>	
								<button class="productViewBtn">View Product</button>
							</a>
						</div>

					</div>
				</div>
				<!-- Product Area End -->
